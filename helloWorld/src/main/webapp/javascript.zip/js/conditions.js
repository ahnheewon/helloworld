// conditions.js

const members = [{ // 상수 변수 const, 새 값 할당 불가능 => 값을 바꿀 수 없다.
    id: 'user1', name: '홍길동', score: 80, phone: '010-1234-1234'}, 
    { id: 'user2', name: '김민식', score: 85, phone: '010-1234-1111'}, 
    { id: 'user3', name: '황의겸', score: 70, phone: '010-1234-4321'}];

    function callFunc(fnc) { //매개 값으로 함수가 올 수 있다!!!
        let name = 'Hong';
        fnc(name);
    }

callFunc(welcomeFnc);
callFunc(helloFnc);



    // function welcomeFnc(param) {
    //     console.log('Welcome ' + param);
    // }
    //같은 내용 간결하게
    let welcomeFnc = function(param) {console.log('Welcome ' + param);} // 단 두 줄 이상인 경우 중괄호 사용.
   

    // function helloFnc(param) {
    //     console.log('Hello ' + param);
    // }
    //같은 내용 간결하게. ES6 버전 부터 가능.
    let helloFnc = (param) => console.log('Hello ' + param); // 단 두 줄 이상인 경우 중괄호 사용.
  